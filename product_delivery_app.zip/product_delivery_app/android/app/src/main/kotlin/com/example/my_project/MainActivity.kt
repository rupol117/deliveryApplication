package com.mycompany.productdeliveryapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
